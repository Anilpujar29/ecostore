# Configuration

Add your devices in devices section in "application.yml" in folder "src/main/resources".

A sample file "application.sample" is also in this folder.

# Start programm
`mvn spring-boot:run`


Please install first Maven on your computer!
